# MirrorStudio · Doble Erre

Identidad elegida para MirrorStudio. Las dos erres de «Mirror» avanzan en un pequeño escalón. La primera abre el gesto y la segunda lo repite. El mismo ritmo guía la animación de arranque.

## Archivos que debes usar

| Uso | Archivo o carpeta |
| --- | --- |
| Icono principal de la aplicación | `Iconos/icono-oficial.svg`, símbolo blanco sobre azul medianoche |
| Icono alternativo para superficies claras | `Iconos/icono-claro.svg`, símbolo medianoche sobre blanco |
| Windows, ejecutable e instalador | `Iconos/Windows/MirrorStudio.ico`, con siete tamaños entre 16 y 256 px |
| Linux | `Iconos/Linux/hicolor/`, con PNG, SVG escalable y símbolo monocromático para bandeja |
| Favicon web | `Iconos/Web/favicon.ico` o `favicon.svg` |
| Iconos PNG con esquinas transparentes | `Iconos/PNG/oficial/` y `Iconos/PNG/claro/` |
| Símbolo sin recuadro | `Marca/isotipo-*.svg` |
| Marca con el nombre, en una línea o apilada | `Marca/logo-horizontal-*.svg` o `Marca/logo-apilado-*.svg` |
| Animación interactiva y adaptable | Abre `Movimiento/demo.html` en el navegador. Incluye repetición, carga lenta y movimiento reducido |
| Implementación para una interfaz web de escritorio | `Movimiento/mirrorstudio-intro.js` |
| Instrucciones para el agente de la aplicación | `PROMPT-AGENTE.txt` |

La lámina de identidad y el video de muestra están en `Referencia/`. El HTML funciona al abrirlo directamente. El MP4 muestra el ritmo en una pantalla de destino ilustrativa. En producción se anima el vector sobre la interfaz real.

## Color, escala y ubicación

La versión oficial lleva el símbolo blanco **#FFFFFF** sobre azul medianoche **#0B1020**. Las firmas de una tinta incluyen medianoche para fondo claro, blanco para fondo oscuro y negro **#000000** para impresión o documentación. El SVG adaptable usa `currentColor` cuando se inserta en línea. Todas las letras del nombre están convertidas a trazados.

Usa el símbolo solo en cabeceras estrechas, favicon y bandeja. En documentación y ventanas con espacio usa la firma horizontal. Conserva la proporción de las erres y deja un margen exterior equivalente, como mínimo, al ancho de un asta vertical. Los archivos de icono ya incluyen su margen. Los PNG de 16, 24 y 32 px usan un dibujo ajustado con algo más de aire entre las dos erres. Para esos tamaños selecciona el PNG correspondiente o el SVG con sufijo `-micro`. Los demás tamaños comparten el dibujo maestro.

## Integración en el paquete de escritorio

- **Windows.** Asigna el ICO multirresolución al ejecutable y a los puntos que el proyecto ya use para el instalador, los accesos directos y el icono de ventana. Comprueba el resultado en el paquete compilado.
- **Linux.** Conserva la estructura de `hicolor` en el directorio de iconos que distribuya tu paquete. Para un lanzador que use el nombre suministrado, la entrada de escritorio puede usar `Icon=mirrorstudio`. Si el producto ya emplea un ID de aplicación, conserva ese ID y adapta el nombre del recurso y la referencia conjuntamente. El archivo simbólico sirve para los componentes que piden una variante de una tinta.
- **Web.** Apunta el enlace de favicon al archivo que empaquetes. Usa los SVG de marca como recursos locales en la interfaz.
- **Pantalla inicial.** Monta la vista real bajo la capa de entrada. Para un destino en la cabecera, usa un contenedor dedicado al isotipo, centrado en ambos ejes. Si la cabecera lleva la firma completa, separa visualmente el símbolo y el nombre en la implementación, o usa el cierre por fundido.

## Ejemplo de conexión del controlador

En un renderer HTML, carga `Movimiento/mirrorstudio-intro.js` como script local. El contenedor `host` debe envolver la vista principal y tener dimensiones definidas y `position: relative` o `fixed`. La capa de entrada y la vista principal serán hermanas. Reserva al ancla una caja con la proporción **372 × 271**, o centra el isotipo con `object-fit: contain`. El controlador mide esa caja durante la transición.

~~~js
// Nombres ilustrativos. Asocia estos objetos al ciclo de vida de tu app.
const boot = prepararVistaPrincipal(); // Promesa real de este arranque.
try {
  await MirrorStudioIntro.play({
    host: contenedorVentana,
    main: pantallaPrincipal,
    anchor: isotipoDeLaCabecera, // null activa el fundido.
    ready: boot,
    focusTarget: primerControlHabitual,
    signal: cicloDeVentana.signal,
    background: '#0B1020',
    ink: '#FFFFFF',
    destinationInk: '#FFFFFF'
  });
} catch (error) {
  if (error.name !== 'AbortError') mostrarErrorDeInicioExistente(error);
}
~~~

En tema claro, pasa `background: '#FFFFFF'`, `ink: '#0B1020'` y el color final real del símbolo en `destinationInk`. Si la tecnología es nativa, implementa la secuencia con sus primitivas de composición y la misma señal de carga. Las dos erres son trazados independientes con los IDs `r-1` y `r-2` en los SVG del isotipo. El controlador respeta la preferencia de movimiento reducido por defecto. El código de integración debe invocarlo una sola vez por arranque en frío.
